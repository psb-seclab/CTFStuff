
# do exercise in this file

# ex 1



# ex 2



# ex 3

def main():
	print 'hello world'
	return


if __name__ == '__main__':
	main()

