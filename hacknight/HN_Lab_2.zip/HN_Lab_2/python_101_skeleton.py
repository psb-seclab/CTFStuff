# -*- coding: utf-8 -*-

def test_db():
	return


def test_network():
	return


def test_exception():
	# opening file failed
	return


def test_module():
	return

def test_class():
	# inheritence
	# overiding
	# operator overloading
	return

def fib_1(n):
	"""Print a Fibonacci series up to n."""
	return


def fib_2(n):
	"""return the nth fib num"""
	return 

def simple_func(a, b, c):
	return a + b + c**3

def test_function():
	return

def test_list_comprehension():
	# the first 100 odd numbers
	# gen a dict
	# gen a ascii code table
	# gen a 10*10 array
	# cross product
	# using if
	return

def test_file_io():
	# write to a file
	# read from a file
	# read as much as possible at one time!
	# read a line at a time
	# reset file obj position
	# tell the current position
	# create a dir
	# 
	return

def test_io():
	# print function
	# get input from keyboard
	# raw_input, get a line of input from keyboard as string
	# input
	return

def test_loops():
	# for loops, break, continue
	# problem: check prime
	# using while loop do the same
	# do while?
	return

def test_control_flow():
	# get input from keyboard
	#x = int(raw_input("Please enter #:"))
	# no case statement
	return

def test_dictionary():
	# create a dictionary
	# add a new entry
	# del a entry
	# check for existance
	# update dict
	# no duplicates!
	# make a copy
	# clear the dict
	return

def test_list():
	# items are ordered
	# items in list can be heterogeneous
	# access list elements
	# loop through a list
	# add a new item to a list
	# delete a item based on location
	#check membership
	# lists cancatenation
	# list repetiion
	# nested list
	# index function
	return


def test_str():
	# take a substring
	# str[left:right]
	# do not modify char in a string
	#str_1[0] = 'H'
	# print the last char
	# check a string's hex
	return

def test_var():
	# the id function
	# global var
	return


if __name__ == "__main__":
    #test_var()
    #test_str()
    #test_list()
    #test_dictionary()
    #test_control_flow()
    #test_loops()
    #test_function()
    #test_io()
    #test_file_io()
    #test_class()
    #test_comprehension()
    #test_module()
    #test_exception()
    pass
